"""
Compares the deep multimodal model against classical ML baselines (Random
Forest, XGBoost) and a naive mean-yield baseline, all trained on the same
synthetic data and checked against the same real held-out Coimbatore rice
fields. Mirrors the baseline-comparison-table structure used in published ML
papers, so results are presented in a defensible, review-ready format.

Run after training the deep model (produces backend/checkpoints/*.pt):
    python -m training.train_forecast_model --mode realistic
    python -m evaluation.run_model_comparison
"""

import torch

from evaluation.baselines.random_forest import train_and_eval as rf_train_and_eval
from evaluation.baselines.xgboost_model import train_and_eval as xgb_train_and_eval
from training.dataset import build_dataset_from_processed, build_synthetic_dataset
from training.train_forecast_model import CHECKPOINT_DIR, ForecastModel, predict_final_yield


def _mae(preds: list[float], actuals: list[float]) -> float:
    return sum(abs(p - a) for p, a in zip(preds, actuals)) / len(actuals)


def main():
    synthetic_train = build_synthetic_dataset(n_examples=300)
    real_holdout = build_dataset_from_processed()
    if not real_holdout:
        raise RuntimeError("No real held-out examples found - run ingestion/align_pipeline.py first.")

    naive_pred = sum(ex.final_yield for ex in synthetic_train) / len(synthetic_train)
    rows = [("Naive baseline (predict train-set mean)", _mae([naive_pred] * len(real_holdout), [ex.final_yield for ex in real_holdout]))]

    rf_result = rf_train_and_eval(synthetic_train, real_holdout)
    rows.append(("Random Forest", rf_result["mae"]))

    xgb_result = xgb_train_and_eval(synthetic_train, real_holdout)
    rows.append(("XGBoost", xgb_result["mae"]))

    ckpt_path = CHECKPOINT_DIR / "fusion_backbone.pt"
    if ckpt_path.exists():
        model = ForecastModel()
        ckpt = torch.load(ckpt_path, map_location="cpu")
        model.vision_enc.load_state_dict(ckpt["vision_enc"])
        model.weather_enc.load_state_dict(ckpt["weather_enc"])
        model.soil_enc.load_state_dict(ckpt["soil_enc"])
        model.fusion.load_state_dict(ckpt["fusion"])
        model.backbone.load_state_dict(ckpt["backbone"])
        model.head.load_state_dict(torch.load(CHECKPOINT_DIR / "yield_head.pt", map_location="cpu"))
        preds, actuals = predict_final_yield(model, real_holdout)
        rows.append(("HarvestWise multimodal model (ours)", _mae(preds, actuals)))
    else:
        print(f"[!] no trained checkpoint at {ckpt_path} - run `python -m training.train_forecast_model --mode realistic` first for the full comparison\n")

    print("=== Model comparison: MAE (t/ha) on real held-out fields (4 states, 2 crops) ===")
    print(
        f"NOTE: {len(real_holdout)} real season examples across "
        f"{len({ex.field_id for ex in real_holdout})} fields spanning Tamil Nadu, Punjab,\n"
        "West Bengal, and Andhra Pradesh (rice + wheat) - see\n"
        "data/raw/yield_labels/README.md for each field's real yield source and its\n"
        "sourcing caveats. Genuine multi-state, multi-crop, multi-year real variation,\n"
        "but still a small sample overall - report it as such.\n"
    )
    for name, mae in sorted(rows, key=lambda r: r[1]):
        print(f"  {name:<40} MAE={mae:.3f} t/ha")


if __name__ == "__main__":
    main()
