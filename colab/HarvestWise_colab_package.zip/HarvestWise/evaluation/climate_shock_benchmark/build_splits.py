"""
Defines the "HarvestWise Climate-Shock Benchmark" splits: which season-years
count as normal vs. climate-shock (drought / heatwave / shifted monsoon),
for your field's region.

TODO(real labels): replace YEAR_LABELS with your region's actual climate
record (a year is a "shock" year if its growing-season rainfall/temperature
anomaly exceeds some threshold vs. the multi-year mean - pull this from the
same ERA5 data ingestion/weather_fetch.py already fetches, or from a public
drought/heat index for your state). This is the file that gets published
publicly alongside the benchmark (see evaluation/climate_shock_benchmark/
README.md once evaluation is complete).
"""

YEAR_LABELS = {
    2016: "normal", 2017: "normal", 2018: "normal",
    2019: "drought", 2020: "normal", 2021: "heatwave",
    2022: "shifted_monsoon", 2023: "normal", 2024: "drought",
}

NORMAL_YEARS = [y for y, label in YEAR_LABELS.items() if label == "normal"]
SHOCK_YEARS = [y for y, label in YEAR_LABELS.items() if label != "normal"]


def split_by_year(examples: list, train_on: str = "normal") -> tuple[list, list]:
    """train_on='normal': train on normal years, test on shock years (the
    benchmark's headline experiment). Returns (train_examples, test_examples)."""
    from datetime import date

    def year_of(ex) -> int:
        return date.fromisoformat(ex.season_start_date).year

    if train_on == "normal":
        train = [ex for ex in examples if year_of(ex) in NORMAL_YEARS]
        test = [ex for ex in examples if year_of(ex) in SHOCK_YEARS]
    else:
        train = [ex for ex in examples if year_of(ex) in SHOCK_YEARS]
        test = [ex for ex in examples if year_of(ex) in NORMAL_YEARS]

    return train, test


def label_for_year(year: int) -> str:
    return YEAR_LABELS.get(year, "unknown")
